﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 2-10-2022
* CSC 153
* Logan Sines
* Drivers License Exam
*/

namespace DLExam
{

    public partial class Form1 : Form
    {
        string[] correctAnswers = new string[] { "B", "D", "A", "A", "C", "A", "B", "A", "C", "D", "B", "C", "D", "A", "D", "C", "C", "B", "D", "A" };
        string[] studentAnswers = new string[] { "B", "A", "A", "D", "C", "A", "B", "A", "D", "D", "B", "C", "D", "C", "D", "C", "C", "B", "D", "A" };
        int i = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var correct = string.Join(Environment.NewLine, correctAnswers);
            MessageBox.Show("The correct answers are: \n" + correct);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var student = string.Join(Environment.NewLine, studentAnswers);
            MessageBox.Show("The student's answers were: \n" + student);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int correctAnswerCount = 0, incorrectAnswerCount = 0;
            for (i = 0; i < 20; i++)
            {
                if (studentAnswers[i].Equals(correctAnswers[i]))
                {
                    correctAnswerCount += 1;
                }
                else
                {
                    incorrectAnswerCount += 1;
                }
            }
            if (correctAnswerCount >= 15)
            {
                MessageBox.Show("Correct Answers Required: 15\nCorrect Answers Obtained: " + correctAnswerCount + "\nYou passed!");
            }
            else
            {
                MessageBox.Show("Correct Answers Required: 15\nCorrect Answers Obtained: " + correctAnswerCount + "\nYou failed.");
            }
        }
    }
}
