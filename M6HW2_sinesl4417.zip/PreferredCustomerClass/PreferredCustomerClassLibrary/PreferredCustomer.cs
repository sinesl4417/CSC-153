﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreferredCustomerClassLibrary
{
    public class PreferredCustomer: Customer
    {
        //Fields
        private double _Purchases;
        private double _Discount;

        //Properties
        public double Purchases { get { return _Purchases; } set { _Purchases = value; } }
        public double Discount { get { return _Discount; } set { _Discount = value; } }

        //Constructor
        public PreferredCustomer(string Name, int Phone, string Address, int CustomerNumber, bool OnMailingList, double Purchases, double Discount) : base(Name, Phone, Address, CustomerNumber, OnMailingList)
        {
            this._Purchases = Purchases;
            this._Discount = Discount;
        }

        public static void CreatePreferredCustomer(string Name, int Phone, string Address, int CustomerNumber, bool OnMailingList, double Purchases, double Discount)
        {
            PreferredCustomer NewCustomer = new PreferredCustomer(Name, Phone, Address, CustomerNumber, OnMailingList, Purchases, Discount);
        }
    }
}
