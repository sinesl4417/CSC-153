﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.nameText = new System.Windows.Forms.TextBox();
            this.addressText = new System.Windows.Forms.TextBox();
            this.customerIDText = new System.Windows.Forms.TextBox();
            this.mailingList = new System.Windows.Forms.ComboBox();
            this.createPreferredCustomer = new System.Windows.Forms.Button();
            this.phoneText = new System.Windows.Forms.TextBox();
            this.purchasesText = new System.Windows.Forms.TextBox();
            this.discountText = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(80, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Phone Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Address:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Customer ID:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 142);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "On Mailing List?:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(43, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Purchases: $";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 200);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Discount (Percent):";
            // 
            // nameText
            // 
            this.nameText.Location = new System.Drawing.Point(133, 27);
            this.nameText.Name = "nameText";
            this.nameText.Size = new System.Drawing.Size(141, 22);
            this.nameText.TabIndex = 1;
            // 
            // addressText
            // 
            this.addressText.Location = new System.Drawing.Point(133, 83);
            this.addressText.Name = "addressText";
            this.addressText.Size = new System.Drawing.Size(141, 22);
            this.addressText.TabIndex = 3;
            // 
            // customerIDText
            // 
            this.customerIDText.Location = new System.Drawing.Point(133, 111);
            this.customerIDText.Name = "customerIDText";
            this.customerIDText.Size = new System.Drawing.Size(141, 22);
            this.customerIDText.TabIndex = 4;
            // 
            // mailingList
            // 
            this.mailingList.FormattingEnabled = true;
            this.mailingList.Items.AddRange(new object[] {
            "True",
            "False"});
            this.mailingList.Location = new System.Drawing.Point(133, 139);
            this.mailingList.Name = "mailingList";
            this.mailingList.Size = new System.Drawing.Size(141, 24);
            this.mailingList.TabIndex = 5;
            // 
            // createPreferredCustomer
            // 
            this.createPreferredCustomer.Location = new System.Drawing.Point(86, 244);
            this.createPreferredCustomer.Name = "createPreferredCustomer";
            this.createPreferredCustomer.Size = new System.Drawing.Size(188, 23);
            this.createPreferredCustomer.TabIndex = 15;
            this.createPreferredCustomer.Text = "Create Preferred Customer";
            this.createPreferredCustomer.UseVisualStyleBackColor = true;
            this.createPreferredCustomer.Click += new System.EventHandler(this.createPreferredCustomer_Click);
            // 
            // phoneText
            // 
            this.phoneText.Location = new System.Drawing.Point(133, 56);
            this.phoneText.Name = "phoneText";
            this.phoneText.Size = new System.Drawing.Size(141, 22);
            this.phoneText.TabIndex = 2;
            // 
            // purchasesText
            // 
            this.purchasesText.Location = new System.Drawing.Point(133, 168);
            this.purchasesText.Name = "purchasesText";
            this.purchasesText.Size = new System.Drawing.Size(141, 22);
            this.purchasesText.TabIndex = 6;
            // 
            // discountText
            // 
            this.discountText.Location = new System.Drawing.Point(133, 197);
            this.discountText.Name = "discountText";
            this.discountText.Size = new System.Drawing.Size(141, 22);
            this.discountText.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(351, 308);
            this.Controls.Add(this.discountText);
            this.Controls.Add(this.purchasesText);
            this.Controls.Add(this.phoneText);
            this.Controls.Add(this.createPreferredCustomer);
            this.Controls.Add(this.mailingList);
            this.Controls.Add(this.customerIDText);
            this.Controls.Add(this.addressText);
            this.Controls.Add(this.nameText);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Preferred Customer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox nameText;
        private System.Windows.Forms.TextBox addressText;
        private System.Windows.Forms.TextBox customerIDText;
        private System.Windows.Forms.ComboBox mailingList;
        private System.Windows.Forms.Button createPreferredCustomer;
        private System.Windows.Forms.TextBox phoneText;
        private System.Windows.Forms.TextBox purchasesText;
        private System.Windows.Forms.TextBox discountText;
    }
}

