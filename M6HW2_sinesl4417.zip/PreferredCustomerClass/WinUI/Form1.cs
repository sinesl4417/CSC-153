﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PreferredCustomerClassLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void createPreferredCustomer_Click(object sender, EventArgs e)
        {
            string Name = nameText.Text;
            int Phone = int.Parse(phoneText.Text); 
            string Address = addressText.Text;
            int CustomerNumber =int.Parse(customerIDText.Text);
            bool OnMailingList = bool.Parse(mailingList.Text);
            double Purchases = double.Parse(purchasesText.Text);
            double Discount = double.Parse(discountText.Text);
            PreferredCustomer NewCustomer = new PreferredCustomer(Name,Phone,Address,CustomerNumber,OnMailingList,Purchases,Discount);
            MessageBox.Show("Customer Name: " + NewCustomer.Name + "\nCustomer Phone Number: " + NewCustomer.Phone + "\nCustomer Address: " + NewCustomer.Address + "\nCustomer ID Number: " + NewCustomer.CustomerNumber + "\nOn Mailing List?: " + NewCustomer.Mail + "\nPurchases: $" + NewCustomer.Purchases + "\nDiscount: " + NewCustomer.Discount + "%");
        }
    }
}
