﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/**
* 2-26-2022
* CSC 153
* Logan Sines
* Random Number Reader
*/

namespace RandomNumberReader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            readRandomNumberFell();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void readRandomNumberFell()
        {
            string name = "";
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Select your random number file:";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                name = dialog.FileName;
                try
                {
                    StreamReader streamReader = new StreamReader(name);
                    string line = streamReader.ReadLine();
                    int num = 0;
                    int sum = 0;
                    int total = 0;
                    while ((line = streamReader.ReadLine()) != null)
                    {
                        num = Convert.ToInt32(line);
                        listBox1.Items.Add(line + "\n");
                        sum += num;
                        total += 1;
                    }
                    listBox1.Items.Add("Total Random Numbers: " + total);
                    listBox1.Items.Add("Sum of Random Numbers: " + sum);
                }
                catch (Exception)
                {
                    MessageBox.Show("ERROR: Unable to load file");
                }
            }
        }
    }
}