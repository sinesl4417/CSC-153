﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace RandomNumberWriter
{
    public partial class Form1 : Form
    {
        private int valueInt;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string textboxValue = textBox1.Text;
            valueInt = Int32.Parse(textboxValue);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            randomNumbers();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void randomNumbers()
        {
            int userVal = valueInt;
            Random random = new Random();
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Title = "Enter name and location of random number file: ";
            string name = "";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                name = dialog.FileName;
            }
            else
            {
                MessageBox.Show("Random.txt has been saved.");
                name = "Random.txt";
            }
            
            try
            {
                StreamWriter streamWriter = new StreamWriter(name);
                for (int i = 0; i < userVal; i++)
                {
                    int randomNumber = random.Next(1, 100);
                    streamWriter.WriteLine(randomNumber);
                }
                streamWriter.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("ERROR");
            }
        }
    }
}
