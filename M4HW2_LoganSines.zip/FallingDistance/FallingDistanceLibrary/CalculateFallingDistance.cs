﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FallingDistanceLibrary
{
    public class CalculateFallingDistance
    {
        public static string FallingDistance(double t)
        {
            double g = 9.8;
            double d = .5 * (g * t);
            string distance = d.ToString();
            return distance;
        }
    }
}
