﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonAndCustomerClassesLibrary
{
    public  class Person
    {
        //Fields
        private string _Name;
        private int _Phone;
        private string _Address;

        //Properties
        public string Name { get { return _Name; } set { _Name = value; } }
        public int Phone { get { return _Phone; } set { _Phone = value; } }
        public string Address { get { return _Address; } set { _Address = value; } }

        //Constructor
        public Person(string Name, int Phone, string Address)
        {
            this._Name = Name;
            this._Phone = Phone;
            this._Address = Address;
        }

        
    }
}
