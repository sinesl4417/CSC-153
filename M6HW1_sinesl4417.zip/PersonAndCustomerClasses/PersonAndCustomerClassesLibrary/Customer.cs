﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonAndCustomerClassesLibrary
{
    public class Customer: Person
    {
        //Fields
        private int _ID;
        private bool _Mail;

        //Properties
        public int CustomerNumber { get { return _ID; } set { _ID = value; } }
        public bool Mail { get { return _Mail; } set { _Mail = value; } }

        //Constructor
        public Customer(string Name, int Phone, string Address, int CustomerNumber, bool OnMailingList): base(Name, Phone, Address)
        {
            this._ID = CustomerNumber;
            this._Mail = OnMailingList;
        }

        public static void CreateNewCustomer(string Name, int Phone, string Address, int CustomerNumber, bool OnMailingList)
        {
            Customer NewCustomer = new Customer(Name, Phone, Address, CustomerNumber, OnMailingList);
        }
    }
}
