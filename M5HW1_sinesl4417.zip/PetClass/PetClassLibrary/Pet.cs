﻿/**
* 3-19-2022
* CSC 153
* Logan Sines
* Pet Class Assignment
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetClassLibrary
{
    public class Pet
    {
        private string _name;
        private string _type;
        private int _age;

        public void setName(string PetName)
        {
            this._name = PetName;
        }
        public void setType(string PetType)
        {
            this._type = PetType;
        }
        public void setAge(int PetAge)
        {
            this._age = PetAge;
        }
        
        public String getName()
        {
            return this._name;
        }
        public String getType()
        {
            return this._type;
        }
        public int getAge()
        {
            return this._age;
        }
    }
}

