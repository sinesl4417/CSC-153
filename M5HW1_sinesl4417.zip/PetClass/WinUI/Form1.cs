﻿/**
* 3-19-2022
* CSC 153
* Logan Sines
* Pet Class Assignment
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PetClassLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void EnterButton_Click(object sender, EventArgs e)
        {
            string name = NameTextBox.Text;
            string age = AgeTextBox.Text;
            string type = TypeTextBox.Text;
            Pet pet = new Pet();
            pet.setName(name);
            pet.setAge(int.Parse(age));
            pet.setType(type);
            MessageBox.Show("Pet Name: " + pet.getName() + "\nPet Age: " + pet.getAge() + "\nPet Type: " + pet.getType());
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
