﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace RandomNumberWriter
{
    public partial class Form1 : Form
    {
        private int valueInt;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string textboxValue = textBox1.Text;
            valueInt = Int32.Parse(textboxValue);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int randomNumbers = valueInt;
            Random random = new Random();
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.ShowDialog();
            string filename = System.IO.Path.GetFileName(saveFileDialog.FileName);
            StreamWriter streamWriter = new StreamWriter(filename);
            for (int i = 0; i < randomNumbers; i++)
            {
                int n = random.Next(1, 100);
                streamWriter.WriteLine(n);
            }
            MessageBox.Show("Random numbers have been written to the file");
            streamWriter.Close(); 
        }
    }
}
