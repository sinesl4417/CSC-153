﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelName = new System.Windows.Forms.Label();
            this.displayName = new System.Windows.Forms.Label();
            this.labelDepartment = new System.Windows.Forms.Label();
            this.employee1 = new System.Windows.Forms.Button();
            this.displayID = new System.Windows.Forms.Label();
            this.labelID = new System.Windows.Forms.Label();
            this.labelPosition = new System.Windows.Forms.Label();
            this.displayDepartment = new System.Windows.Forms.Label();
            this.displayPosition = new System.Windows.Forms.Label();
            this.employee2 = new System.Windows.Forms.Button();
            this.employee3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(87, 9);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(47, 16);
            this.labelName.TabIndex = 0;
            this.labelName.Text = "Name:";
            // 
            // displayName
            // 
            this.displayName.AutoSize = true;
            this.displayName.Location = new System.Drawing.Point(140, 9);
            this.displayName.Name = "displayName";
            this.displayName.Size = new System.Drawing.Size(85, 16);
            this.displayName.TabIndex = 1;
            this.displayName.Text = "[Name Here]";
            // 
            // labelDepartment
            // 
            this.labelDepartment.AutoSize = true;
            this.labelDepartment.Location = new System.Drawing.Point(54, 73);
            this.labelDepartment.Name = "labelDepartment";
            this.labelDepartment.Size = new System.Drawing.Size(80, 16);
            this.labelDepartment.TabIndex = 2;
            this.labelDepartment.Text = "Department:";
            // 
            // employee1
            // 
            this.employee1.Location = new System.Drawing.Point(102, 148);
            this.employee1.Name = "employee1";
            this.employee1.Size = new System.Drawing.Size(112, 23);
            this.employee1.TabIndex = 3;
            this.employee1.Text = "Employee 1";
            this.employee1.UseVisualStyleBackColor = true;
            this.employee1.Click += new System.EventHandler(this.button1_Click);
            // 
            // displayID
            // 
            this.displayID.AutoSize = true;
            this.displayID.Location = new System.Drawing.Point(140, 40);
            this.displayID.Name = "displayID";
            this.displayID.Size = new System.Drawing.Size(112, 16);
            this.displayID.TabIndex = 4;
            this.displayID.Text = "[ID Number Here]";
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Location = new System.Drawing.Point(60, 40);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(74, 16);
            this.labelID.TabIndex = 5;
            this.labelID.Text = "ID Number:";
            // 
            // labelPosition
            // 
            this.labelPosition.AutoSize = true;
            this.labelPosition.Location = new System.Drawing.Point(76, 105);
            this.labelPosition.Name = "labelPosition";
            this.labelPosition.Size = new System.Drawing.Size(58, 16);
            this.labelPosition.TabIndex = 6;
            this.labelPosition.Text = "Position:";
            // 
            // displayDepartment
            // 
            this.displayDepartment.AutoSize = true;
            this.displayDepartment.Location = new System.Drawing.Point(140, 73);
            this.displayDepartment.Name = "displayDepartment";
            this.displayDepartment.Size = new System.Drawing.Size(118, 16);
            this.displayDepartment.TabIndex = 7;
            this.displayDepartment.Text = "[Department Here]";
            // 
            // displayPosition
            // 
            this.displayPosition.AutoSize = true;
            this.displayPosition.Location = new System.Drawing.Point(140, 105);
            this.displayPosition.Name = "displayPosition";
            this.displayPosition.Size = new System.Drawing.Size(96, 16);
            this.displayPosition.TabIndex = 8;
            this.displayPosition.Text = "[Position Here]";
            // 
            // employee2
            // 
            this.employee2.Location = new System.Drawing.Point(102, 177);
            this.employee2.Name = "employee2";
            this.employee2.Size = new System.Drawing.Size(112, 23);
            this.employee2.TabIndex = 9;
            this.employee2.Text = "Employee 2";
            this.employee2.UseVisualStyleBackColor = true;
            this.employee2.Click += new System.EventHandler(this.employee2_Click);
            // 
            // employee3
            // 
            this.employee3.Location = new System.Drawing.Point(102, 206);
            this.employee3.Name = "employee3";
            this.employee3.Size = new System.Drawing.Size(112, 23);
            this.employee3.TabIndex = 10;
            this.employee3.Text = "Employee 3";
            this.employee3.UseVisualStyleBackColor = true;
            this.employee3.Click += new System.EventHandler(this.employee3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(328, 260);
            this.Controls.Add(this.employee3);
            this.Controls.Add(this.employee2);
            this.Controls.Add(this.displayPosition);
            this.Controls.Add(this.displayDepartment);
            this.Controls.Add(this.labelPosition);
            this.Controls.Add(this.labelID);
            this.Controls.Add(this.displayID);
            this.Controls.Add(this.employee1);
            this.Controls.Add(this.labelDepartment);
            this.Controls.Add(this.displayName);
            this.Controls.Add(this.labelName);
            this.Name = "Form1";
            this.Text = "Employee";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label displayName;
        private System.Windows.Forms.Label labelDepartment;
        private System.Windows.Forms.Button employee1;
        private System.Windows.Forms.Label displayID;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.Label labelPosition;
        private System.Windows.Forms.Label displayDepartment;
        private System.Windows.Forms.Label displayPosition;
        private System.Windows.Forms.Button employee2;
        private System.Windows.Forms.Button employee3;
    }
}

