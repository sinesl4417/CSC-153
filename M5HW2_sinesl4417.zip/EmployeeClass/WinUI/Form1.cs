﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeClassLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        Employee[] EmployeeList = new Employee[3];

        public Form1()
        {
            InitializeComponent();
        }

        private void EmployeeInfo()
        {
            EmployeeList[0] = new Employee("Susan Meyers", "47899", "Accounting", "Vice President");
            EmployeeList[1] = new Employee("Mark Jones", "39119", "IT", "Programmer");
            EmployeeList[2] = new Employee("Joy Rogers", "81774", "Manufacturing", "Engineer");
        }
            
        private void button1_Click(object sender, EventArgs e)
        {
            EmployeeInfo();
            displayName.Text = EmployeeList[0]._Name;
            displayID.Text = EmployeeList[0]._IDNumber;
            displayDepartment.Text = EmployeeList[0]._Department;
            displayPosition.Text = EmployeeList[0]._Position;
        }

        private void employee2_Click(object sender, EventArgs e)
        {
            EmployeeInfo();
            displayName.Text = EmployeeList[1]._Name;
            displayID.Text = EmployeeList[1]._IDNumber;
            displayDepartment.Text = EmployeeList[1]._Department;
            displayPosition.Text = EmployeeList[1]._Position;
        }

        private void employee3_Click(object sender, EventArgs e)
        {
            EmployeeInfo();
            displayName.Text = EmployeeList[2]._Name;
            displayID.Text = EmployeeList[2]._IDNumber;
            displayDepartment.Text = EmployeeList[2]._Department;
            displayPosition.Text = EmployeeList[2]._Position;
        }
    }
}
